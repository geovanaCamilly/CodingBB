const nome = "Geo";
const idade = 2022-2005;
const cidadeDeNascimento = "Brasília";

// const apresentacao = "meu nome é " + nome + ", minha idade é " + idade + " e nasci na cidade de " + cidadeDeNascimento;

const apresentacao = `meu nome é ${nome}, minha idade é ${idade}, e nasci na cidade de ${cidadeDeNascimento}`;

console.log(apresentacao)
