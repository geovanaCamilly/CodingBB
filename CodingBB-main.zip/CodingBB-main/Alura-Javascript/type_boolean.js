//===(3 vezes) é igual a comparação
//== quer dizer igual
//= quer dizer recebe



const primeiroNumero = 5;
const segundoNumero = 5;
let cadastroAtivado = true;

//console.log(primeiroNumero === segundoNumero);

const texto1 = "Rosa";
const texto2 = "rosa";

console.log(texto1 === texto2)