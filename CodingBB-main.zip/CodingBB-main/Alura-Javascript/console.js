// log -> registro

const minhaVar = true;

// console.log(245)
// console.log("eu sou um texto")
// console.log(minhaVar)

// tratamento de erro!

console.error('deu erro!')