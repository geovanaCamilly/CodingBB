// tipagem dinâmia

let minhaVar = 876;
minhaVar = "texto";
minhaVar = true;
