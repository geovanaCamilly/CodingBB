
const cidade = "brasilia Linda";
const input = "Brasilia";

const inputMinusculo = input.toLowerCase();

console.log(cidade === inputMinusculo); 


