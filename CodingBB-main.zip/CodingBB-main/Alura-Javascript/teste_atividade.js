console.log("deu erro!");
console.error(new Error("deu erro"));