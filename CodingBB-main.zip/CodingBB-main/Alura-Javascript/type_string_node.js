const texto1 = "Olá, mundo!";
const texto2 = "Olá, mundo!";
const senha = "senhaSuperSegura456!";
const StringDeNumeros = "34567";

const citacao = "Meu nome é ";
const meuNome = "Geovana ";
const citacao2 = "e meu amigo se chama ";
const meuAmigo = "Moises";

// concatenação (+)

console.log(citacao + meuNome + citacao2 + meuAmigo)

//template string OU template literal