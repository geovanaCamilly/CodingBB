// tipo de dado
// booleanos

// conversão implicíta
const numero = 765;
const numeroString = Number("765a");

//Number()
//String()

console.log(numero + numeroString)


// conversão implicíta