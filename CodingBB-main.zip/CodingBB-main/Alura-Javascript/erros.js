const numero = 1;
console.log(minhaVar);