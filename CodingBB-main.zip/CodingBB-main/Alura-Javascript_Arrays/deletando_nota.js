const notas = [10, 6, 8, 5, 10]
notas.pop()

console.log(notas)

media = (notas[0] + notas[1] + notas[2] + notas[3])/notas.length
console.log('A media é ${media}')