const salaDePython = ['Melissa' , 'Helena' , 'Rodrigo']

const salaDeJavaScript = ['Ju' , 'Leo' , 'Raquel']

const salaUnificadas = salaDePython.concat(salaDeJavaScript)

console.log(salaUnificadas)