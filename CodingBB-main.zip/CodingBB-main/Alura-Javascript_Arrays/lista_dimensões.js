const listaDeAlunos = ['João', 'Juliana', 'Caio', 'Ana' ]

const Media = [10, 8, 7.5, 9]

let listaDeNotasEAlunos = [listaDeAlunos, Media]

console.log(`${listaDeNotasEAlunos[0][0]}, sua media é ${listaDeNotasEAlunos[1][0]}`)

