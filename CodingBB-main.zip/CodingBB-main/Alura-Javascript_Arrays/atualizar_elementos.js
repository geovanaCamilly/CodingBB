const listaDeChamada = ['João', 'Ana', 'Ryan', 'Matheus', 'Moises', 'Antonio']

//listaDeChamada.splice(1,2,'Rodrigo')
listaDeChamada.splice(2, 0, 'Rodrigo')

console.log(`A nova lista de alunos é: ${listaDeChamada}`)