                      //1
const numeros = [100, 200, 300, 400, 500, 600]
    //i = 1       //tamanho da array(6)
for (let i = 0; i < numeros.length; i++){
                // numeros[0]
    console.log(i, numeros[i])
}