const nomes = ["Paola", "Raiane", "Poze", "Manuel"]

nomes.forEach(ImprimeNomes)

function ImprimeNomes(nome){
    console.log(nome)
}