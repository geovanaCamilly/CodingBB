var nome = "giulia cachorra"
var frase1 = "feliz segunda feira"


function vadia(){

    return `oi ${nome}, ${frase1}`

} 


console.log(vadia())
