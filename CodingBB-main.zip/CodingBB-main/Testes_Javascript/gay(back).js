const texto = "teu pai sabe que tu eh gay??"


if (texto == "n") {
    texto = "ta na hora de contarkkkkkkkkkkk"
}

console.log(texto);