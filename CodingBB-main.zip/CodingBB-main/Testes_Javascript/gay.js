const gay = ("teu pai sabe que tu eh gay??");

console.log(gay)

if (gay == "n") {

     "ta na hora de contarkkkkkkkkkkk" 

} else {
         "problema seu"

    }

    console.log(gay);

