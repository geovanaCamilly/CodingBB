const listaRoupas = [

    { titulo: "Camisa",
      preco: 20
    },

    { titulo: "calça",
      preco: 50
    },

    { titulo: "sapato",
      preco: 100
    },

    {
      titulo: "chapeu",
      preco: 10
    }

];

module.exports = listaRoupas