var nome = 'ana'
var mensagem = 'boa tarde compre uma bolsinha de mim'

function aninha(){

    return `ola ${nome} pf ${mensagem}`
}

console.log(aninha())
