 const listaLivros = [
    {
        titulo: "Go",
        preco: 45  
    },
    {
        titulo: "C++",
        preco: 35
    },
    {
        titulo: "Java",
        preco: 30
    },
    {
        titulo: "PHP",
        preco: 15
    },
    {
        titulo: "Elixir",
        preco: 50
    },
    {
        titulo: "Rust",
        preco: 28
    },
    {
        titulo: "Scala",
        preco: 40
    },
    {
        titulo: "Ruby",
        preco: 28
    },
    {
        titulo: "JavaScript",
        preco: 25
    },
    {
        titulo: "C#",
        preco: 33
    },
    {
        titulo: "Python",
        preco: 20
    }
]

module.exports = {listaLivros}
