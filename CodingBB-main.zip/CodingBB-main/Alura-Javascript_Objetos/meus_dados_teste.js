const eu = {
    nome:"Geovana",
    telefone:"61992016426",
    cidade:"Brasilia",
    dataNasc:"19/09/2008"
}

console.log(eu)

eu.dataNasc = "19/092005"

console.log(eu)

delete eu.cidade

console.log(eu)