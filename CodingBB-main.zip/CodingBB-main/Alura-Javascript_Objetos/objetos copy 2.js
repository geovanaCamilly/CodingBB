const listsCPFs = ["27467621566", "2364728687", "927636546"]

// const cliente = ["nome", "André", "idade", 36]

const cliente = {
    nome: "Andre",
    idade:36,
    cpf:"82675659",
    email:"andre@email.com"
}