const cliente = {
    nome: "Andre",
    idade:36,
    cpf:"82675659",
    email:"andre@email.com"
}


cliente.fone ="9372556"



console.log(cliente)