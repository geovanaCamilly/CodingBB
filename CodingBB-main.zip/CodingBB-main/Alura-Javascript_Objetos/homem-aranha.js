const heroi = {
    nome:"Peter Parker",
    dataNascimento:"25/05/1990",
    identidade:"835647-837",
    email:"peter@email.com",
    telefone:"82765639",
    cidade:"Nova york",
    estado:"EUA"
}

heroi.cpf = "6535736185"

console.log(heroi)