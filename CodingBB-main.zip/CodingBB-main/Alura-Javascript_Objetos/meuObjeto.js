const cachorro = {
nome: "lilica",
raça: "pudlle",      
pelagem: "branca",
tutores: {
    dona1: "Geo",
    dona2: "Jo"
},
dócil: true, //boleano
brinquedos: ["bolinha", "meia", 'urso'] //array
}

// latir: function() {
//     console.log(auau)
