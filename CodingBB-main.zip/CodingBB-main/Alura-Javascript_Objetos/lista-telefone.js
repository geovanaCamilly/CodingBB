const cliente = {
    nome: "Andre",
    idade:36,
    cpf:"82675659",
    email:"andre@email.com",
   fones:["656564900","53499801"]
}

cliente.fones.forEach(fone => console.log(fone))